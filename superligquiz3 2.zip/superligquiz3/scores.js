document.addEventListener('DOMContentLoaded', () => {
    const scores = JSON.parse(localStorage.getItem('scores')) || [];
    const scoreTable = document.getElementById('score-table').getElementsByTagName('tbody')[0];

    scores.sort((a, b) => b.score - a.score);

    scores.forEach(score => {
        const row = document.createElement('tr');
        const usernameCell = document.createElement('td');
        const scoreCell = document.createElement('td');
        usernameCell.textContent = score.username;
        scoreCell.textContent = score.score;
        row.appendChild(usernameCell);
        row.appendChild(scoreCell);
        scoreTable.appendChild(row);
    });
});
