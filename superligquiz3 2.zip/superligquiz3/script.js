const questions = [
    {
        question: "1959 yılında Türkiye Süper Ligi'ni hangi takım kazandı?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
  {
        question: "1959-1960 yılında Türkiye Süper Ligi'ni hangi takım kazandı?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
    {
        question: "1960-61 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1961-62 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
    {
        question: "1962-63 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
    {
        question: "1963-64 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1964-65 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1965-66 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
    {
        question: "1966-67 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
    {
        question: "1967-68 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1968-69 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
    {
        question: "1969-70 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1970-71 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
    {
        question: "1971-72 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
    {
        question: "1972-73 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
    {
        question: "1973-74 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1974-75 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1975-76 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 3
    },
    {
        question: "1976-77 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 3
    },
    {
        question: "1977-78 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1978-79 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
        {text: "Fenerbahçe", image: "images/fenerbahce.png"},
        {text: "Beşiktaş", image: "images/besiktas.png"},
        {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 3
    },
    {
        question: "1979-80 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 3
    },
    {
        question: "1980-81 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 3
    },
    {
        question: "1981-82 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
    {
        question: "1982-83 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1983-84 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 3
    },
    {
        question: "1984-85 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
    {
        question: "1985-86 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
    {
        question: "1986-87 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "1987-88 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "1988-89 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
  {
        question: "1989-90 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "1990-91 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "1991-92 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "1992-93 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "1993-94 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "1994-95 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "1995-96 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
  {
        question: "1996-97 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "1997-98 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "1998-99 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "1999-2000 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2000-2001 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
  {
        question: "2001-2002 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2002-2003 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "2003-2004 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
  {
        question: "2004-2005 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
  {
        question: "2005-2006 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2006-2007 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
  {
        question: "2007-2008 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2008-2009 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "2009-2010 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Çorumspor", image: "images/corumspor.png"},
            {text: "Bursaspor", image: "images/bursaspor.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "2010-2011 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
  {
        question: "2011-2012 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2012-2013 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2013-2014 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Fenerbahçe", image: "images/fenerbahce.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2014-2015 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Çorumspor", image: "images/corumspor.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2015-2016 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "İstanbul Başakşehir", image: "images/basaksehir.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "2016-2017 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "İstanbul Başakşehir", image: "images/basaksehir.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "2017-2018 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "İstanbul Başakşehir", image: "images/basaksehir.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2018-2019 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "İstanbul Başakşehir", image: "images/basaksehir.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2019-2020 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "İstanbul Başakşehir", image: "images/basaksehir.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 1
    },
  {
        question: "2020-2021 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "İstanbul Başakşehir", image: "images/basaksehir.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 2
    },
  {
        question: "2021-2022 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "İstanbul Başakşehir", image: "images/basaksehir.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 3
    },
  {
        question: "2022-2023 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Ankaragücü", image: "images/ankaragucu.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
  {
        question: "2023-2024 sezonunda hangi takım şampiyon oldu?",
        options: [{text: "Galatasaray", image: "images/galatasaray.png"},
            {text: "Ankaragücü", image: "images/ankaragucu.png"},
            {text: "Beşiktaş", image: "images/besiktas.png"},
            {text: "Trabzonspor", image: "images/trabzonspor.png"}],
        answer: 0
    },
];

const selectedQuestions = questions.sort(() => Math.random() - 0.5).slice(0, 10);

let currentQuestion = 0;
let score = 0;
let timer;
let timeLeft = 10;
let username = "";

document.getElementById('startBtn').onclick = () => {
    username = document.getElementById('username').value;
    if (username === "") {
        alert("Lütfen bir kullanıcı adı girin.");
        return;
    }
    document.getElementById('login').style.display = 'none';
    document.getElementById('quiz-container').style.display = 'block';
    loadQuestion();
};

document.getElementById('showScoresBtn').onclick = () => {
    window.location.href = 'scores.html';
};

function loadQuestion() {
    clearInterval(timer);
    const quizDiv = document.getElementById('quiz');
    quizDiv.innerHTML = "";
    if (currentQuestion < selectedQuestions.length) {
        const q = selectedQuestions[currentQuestion];
        const questionDiv = document.createElement('div');
        questionDiv.classList.add('quiz-item');
        const questionTitle = document.createElement('h2');
        questionTitle.textContent = q.question;
        questionDiv.appendChild(questionTitle);
        q.options.forEach((option, index) => {
            const optionDiv = document.createElement('div');
            optionDiv.classList.add('option');
            const optionImage = document.createElement('img');
            optionImage.src = option.image;
            optionImage.alt = option.text;
            optionImage.classList.add('option-image');
            optionDiv.appendChild(optionImage);
            optionDiv.onclick = () => checkAnswer(index);
            questionDiv.appendChild(optionDiv);
        });
        quizDiv.appendChild(questionDiv);
        timeLeft = 10;
        document.getElementById('timer').textContent = `Süre: ${timeLeft}`;
        timer = setInterval(() => {
            timeLeft--;
            document.getElementById('timer').textContent = `Süre: ${timeLeft}`;
            if (timeLeft <= 0) {
                clearInterval(timer);
                currentQuestion++;
                loadQuestion();
            }
        }, 1000);
    } else {
        showResult();
    }
}

function checkAnswer(selectedOption) {
    clearInterval(timer);
    const q = selectedQuestions[currentQuestion];
    const options = document.querySelectorAll('.option');
    if (selectedOption === q.answer) {
        options[selectedOption].classList.add('correct');
        score++;
    } else {
        options[selectedOption].classList.add('wrong');
        options[q.answer].classList.add('correct');
    }
    setTimeout(() => {
        currentQuestion++;
        loadQuestion();
    }, 1000);
}

function showResult() {
    const quizDiv = document.getElementById('quiz');
    quizDiv.innerHTML = "";
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = `Skorunuz: ${score} / ${selectedQuestions.length}`;
    saveScore(username, score);
    if (score >= 5) {
        resultDiv.innerHTML += "<br>Tebrikler! Kazandınız!";
    } else {
        resultDiv.innerHTML += "<br>GAME OVER";
    }
    document.getElementById('restart').style.display = 'block';
    document.getElementById('timer').style.display = 'none';
}

document.getElementById('restart').onclick = () => {
    currentQuestion = 0;
    score = 0;
    loadQuestion();
    document.getElementById('result').innerHTML = "";
    document.getElementById('restart').style.display = 'none';
    document.getElementById('timer').style.display = 'block';
};

function saveScore(username, score) {
    let scores = JSON.parse(localStorage.getItem('scores')) || [];
    scores.push({ username, score });
    localStorage.setItem('scores', JSON.stringify(scores));
}
